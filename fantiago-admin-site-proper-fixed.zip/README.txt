
# Fantiago Admin Website

## Admin Login

URL:
 /admin/index.html

Username:
fantiago

Password:
raven96

## Features
- Editable homepage
- Editable membership page
- Editable members page
- Editable editorial/blog page
- Live content editing
- Pricing edits
- Membership management
- Admin dashboard
- Netlify-ready deployment

## Deployment
1. Upload entire folder to GitHub
2. Connect GitHub repo to Netlify
3. Deploy

OR

Drag and drop the ZIP directly into Netlify deploy area.
